package com.test.myclient1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyClient1ApplicationTests {

	@Test
	void contextLoads() {
	}

}

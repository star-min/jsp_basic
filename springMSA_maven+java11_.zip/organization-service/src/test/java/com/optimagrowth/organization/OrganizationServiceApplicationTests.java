package com.optimagrowth.organization;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrganizationServiceApplicationTests {

	@Disabled
	void contextLoads() {
	}

}

package com.test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyConfigClient1ApplicationTests {

	@Test
	void contextLoads() {
	}

}

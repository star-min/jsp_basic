package com.example.eurekaclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Service04Application {

	public static void main(String[] args) {
		SpringApplication.run(Service04Application.class, args);
	}

}

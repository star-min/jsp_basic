package com.example.eurekaclient.controllers;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.eurekaclient.model.Member;

@RestController
public class MemberController {

	@RequestMapping(value="/user", method=RequestMethod.GET)
	public Member getInfo() {
		Member m = new Member();
		m.setId("kim");
		m.setName("김기태");
		return m;
	}
}
package com.test;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.web.bind.annotation.GetMapping;

import com.test.controllers.ConsumerControllerClient;

@SpringBootApplication
public class LoadBalancerApplication {

	public static void main(String[] args) {
		ApplicationContext ctx = SpringApplication.run(LoadBalancerApplication.class, args);	
		ConsumerControllerClient consumerControllerClient = 
				ctx.getBean(ConsumerControllerClient.class);
		System.out.println(consumerControllerClient);
		System.out.println(consumerControllerClient);
		for(int inx = 0; inx <= 10; inx++) {
			consumerControllerClient.getMember();
		}
	}
}
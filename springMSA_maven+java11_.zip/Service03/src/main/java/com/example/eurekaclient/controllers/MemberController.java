package com.example.eurekaclient.controllers;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.eurekaclient.model.Member;

@RestController
public class MemberController {

	@RequestMapping(value="/hello", method=RequestMethod.GET)
	public Member getInfo() {
		Member m = new Member();
		m.setId("hello");
		m.setName("헬로우");
		return m;
	}
}
package com.example.eurekaclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Service03Application {

	public static void main(String[] args) {
		SpringApplication.run(Service03Application.class, args);
	}

}

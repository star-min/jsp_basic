package com.example.eurekaclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Service03ApplicationTests {

	@Test
	void contextLoads() {
	}

}
